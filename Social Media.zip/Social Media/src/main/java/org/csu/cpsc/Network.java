package src.main.java.org.csu.cpsc;

import java.util.*;

public class Network {
    private Map<Account, Map<Account, Integer>> adjList;

    public Network(){
        adjList = new HashMap<Account, Map<Account, Integer>>();
    }

    // Method required by Main.java
    public void addAccount(Account account) {
        addAccountNode(account);
    }

    // Method required by Main.java
    public void addConnection(String username1, String username2) {
        Account account1 = getAccount(username1);
        Account account2 = getAccount(username2);

        if (account1 != null && account2 != null) {
            // Assuming a default weight of 1 and bidirectional connection
            addConnectionEdge(account1, account2, 1);
            addConnectionEdge(account2, account1, 1); // Add connection in the other direction too
        }
    }

    public void addAccountNode(Account vertex){
        adjList.putIfAbsent(vertex, new HashMap<Account, Integer>());
    }

    public void addConnectionEdge(Account source, Account destination, int weight){
        if(! adjList.containsKey(source)){
            addAccountNode(source);
        }

        if(! adjList.containsKey(destination)){
            addAccountNode(destination);
        }

        adjList.get(source).put(destination, weight);
    }

    public Set<Account> getAccountNodes(){
        return adjList.keySet();
    }

    public Account getAccount(String username){
        for(Account a: adjList.keySet()){
            // Corrected: Compare usernames, not Account object to String
            if(a.getUserName().equals(username)){
                return a;
            }
        }
        return null;
    }

   public Set<Account> getConnections(String username){
    Account account = getAccount(username);
    if (account == null) {
        return null;
    }
    return adjList.get(account).keySet();
}
    public boolean hasDistantConnection(Account source, Account destination){
    if (!adjList.containsKey(source) || !adjList.containsKey(destination)) {
        return false;
    }

    Set<Account> visited = new HashSet<>();
    Queue<Account> queue = new LinkedList<>();
    queue.add(source);

    while (!queue.isEmpty()) {
        Account current = queue.poll();
        if (current.equals(destination)) {
            return true;
        }
        visited.add(current);
        for (Account neighbor : adjList.get(current).keySet()) {
            if (!visited.contains(neighbor)) {
                queue.add(neighbor);
            }
        }
    }

    return false;
}

public List<Account> shortestConnectionPath(Account source, Account destination) {
    if (!adjList.containsKey(source) || !adjList.containsKey(destination)) {
        return null;
    }

    Map<Account, Account> parentMap = new HashMap<>();
    Set<Account> visited = new HashSet<>();
    Queue<Account> queue = new LinkedList<>();

    queue.add(source);
    visited.add(source);

    while (!queue.isEmpty()) {
        Account current = queue.poll();
        if (current.equals(destination)) {
            // Reconstruct the path
            List<Account> path = new LinkedList<>();
            for (Account at = destination; at != null; at = parentMap.get(at)) {
                path.add(0, at);
            }
            return path;
        }

        for (Account neighbor : adjList.get(current).keySet()) {
            if (!visited.contains(neighbor)) {
                visited.add(neighbor);
                parentMap.put(neighbor, current);
                queue.add(neighbor);
            }
        }
    }

    return null; // Return null if destination is not reachable
}

}



