package src.main.java.org.csu.cpsc;

import java.util.*;

public class PostHistory {
    private List<Post> posts;

    public PostHistory(){
        // Instantiate a List to store the posts.
        this.posts = new ArrayList<>();
    }

    public void addPost(Post post){
        // Add a post to the posts list.
        posts.add(post);
    }

    public List<Post> getNewestPosts(int quantity) {
        // Sort newest-first, then return up to quantity items
        sortPostsByDate();  // now posts[0] is newest
        int take = Math.min(quantity, posts.size());
        List<Post> result = new ArrayList<>(posts.subList(0, take));
        System.out.println("Total posts: " + posts.size());
        return result;
    }

    public List<Post> getOldestPosts(int quantity) {
        // We can sort newest-first and then read from the end backward,
        // or write a small ascending sort. Here: read from end backward.
        sortPostsByDate();  // newest-first
        int size = posts.size();
        int take = Math.min(quantity, size);
        List<Post> oldest = new ArrayList<>();
        // collect last 'take' elements (oldest)
        for (int i = size - take; i < size; i++) {
            oldest.add(posts.get(i));
        }
        return oldest;
    }

    public Queue<Post> getHighestLikedPosts() {
        // Max-heap by likes (highest first)
        PriorityQueue<Post> pq = new PriorityQueue<>(Collections.reverseOrder());
        pq.addAll(posts);
        return pq;
    }

    public Stack<Post> getLowestLikedPosts() {
        //  The lowest-like post to pop off first.
        // So push in descending in a order highest first and lowest last).
        List<Post> copy = new ArrayList<>(posts);
        // sort going up by likes which is lowest first), then reverse to get highest first
        copy.sort(Comparator.naturalOrder());      // naturalOrder uses our compareTo = likes asc
        Collections.reverse(copy);                 // now copy[0] is highest, last is lowest

        Stack<Post> stack = new Stack<>();
        for (Post p : copy) {
            stack.push(p);
        }
        return stack;
    }

    private void sortPostsByDate(){
        // Insertion‐sort posts by postDate, newest date first.
        // Assumes postDate strings compare lex in ISO format, e.g. "2025-04-30".
        for (int i = 1; i < posts.size(); i++) {
            Post key = posts.get(i);
            int j = i - 1;
            // compare strings so that later dates (lex larger) come first
            while (j >= 0 && posts.get(j).getPostDate().compareTo(key.getPostDate()) < 0) {
                posts.set(j + 1, posts.get(j));
                j--;
            }
            posts.set(j + 1, key);
        }
    }
}
