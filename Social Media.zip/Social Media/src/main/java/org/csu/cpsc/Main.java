package src.main.java.org.csu.cpsc;

public class Main {
    public static void main(String[] args) {
        Account alice = new Account("jane123", "Smith", "alice01");
        Account bob   = new Account("Bob",   "Jones", "bob99");

        Network net = new Network();
        net.addAccount(alice);
        net.addAccount(bob);
        net.addConnection("alice01", "bob99");

        System.out.println("Alices connections: " + net.getConnections("alice01"));
        // Should print something like: [Account{username='bob99', ...}]

        PostHistory history = new PostHistory();
        history.addPost(new Post("04-01-2025", "Hello world!", 5));
        history.addPost(new Post("2025-04-29", "Second post", 10));

        System.out.println("Newest post: " + history.getNewestPosts(1));
        // Should show the 4/30 post first
    }
}
