package src.main.java.org.csu.cpsc;

public class Post implements Comparable<Post>{
    final private String postId;
    final private String postDate;
    private int likes;
    private String contents;

    public Post(String date, String contents, int likes){
        postId = Integer.toString(this.hashCode());
        this.postDate = date;
        this.contents = contents;
        this.likes = likes;
    }

    public String getPostID() {
        return postId;
    }

    public String getPostDate() {
        return postDate;
    }

    public String getPostContents() {
        return contents;
    }

    public int getLikes() {
        return likes;
    }

    public String toString(){
        return "Date: " + postDate + " -- " + contents + " -- Likes:" + likes;
    }

   @Override
public int compareTo(Post o) {
    // Compare this post’s likes to the other post’s likes
    
    return Integer.compare(this.likes, o.likes);

}
}
