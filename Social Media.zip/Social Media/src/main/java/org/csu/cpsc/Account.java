package src.main.java.org.csu.cpsc;

public class Account {
    final private String userName;
    private String firstName;
    private String lastName;
    private PostHistory posts;


    public Account(String firstName, String lastName, String userName){
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        posts = new PostHistory();
    }

    public PostHistory getPostHistory(){
        return posts;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setFirstName(String name) {
        this.firstName = name;
    }

    public void setLastName(String name) {
        this.lastName = name;
    }

    public String toString(){
        return "Name: " + firstName + " " + lastName + " - Username: " + userName;
    }

    @Override
public int hashCode() {
    return userName != null ? userName.hashCode() : 0;
}

@Override
public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null || getClass() != obj.getClass()) return false;
    Account account = (Account) obj;
    return userName != null ? userName.equals(account.userName) : account.userName == null;
}

}